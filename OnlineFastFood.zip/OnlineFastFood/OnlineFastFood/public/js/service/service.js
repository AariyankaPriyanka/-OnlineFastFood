//create the service to get the movie collections 
fastFoodApp.factory("fastFoodBasket", function ($resource) {
  //request the /foodItems to server and get the response of collection of food items
  return $resource("/foodItems");
});

//create the service to get the bookings information
fastFoodApp.factory('foodPurchaseFactory', function ($resource) {
  //request the /purchases to server and get the response of the purchases information
  return $resource('/purchases');
});